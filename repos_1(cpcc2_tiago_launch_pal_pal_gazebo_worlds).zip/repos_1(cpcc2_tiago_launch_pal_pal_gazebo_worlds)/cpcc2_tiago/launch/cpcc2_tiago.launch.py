# Copyright (c) 2022 PAL Robotics S.L. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from launch import LaunchDescription
from launch.actions import TimerAction, ExecuteProcess
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
#from launch_pal.include_utils import include_launch_py_description




def generate_launch_description():
    print("flag 0")
    
    # Lance pveg_chained_controller avec Electric Fence
    pveg_chained_controller_launch = ExecuteProcess(
        cmd=['ros2', 'launch', 'cpcc2_tiago', 'pveg_chained_controller.launch.py'],
        output='screen'
    )



    # Lance crocoddyl_controller sans Electric Fence
    crocoddyl_controller_launch = ExecuteProcess(
        cmd=['ros2', 'launch', 'cpcc2_tiago', 'crocoddyl_controller.launch.py'],
        output='screen'
    )
    
#prefix=['valgrind --tool=callgrind --dump-instr=yes -v --instr-atstart=no'],   
    
#    pveg_chained_controller_launch = include_launch_py_description(
#        "cpcc2_tiago", ["launch", "pveg_chained_controller.launch.py"],
#         prefix=['env', 'LD_PRELOAD=libefence.so.0.0']
#    )

#    crocoddyl_controller_launch = include_launch_py_description(
#        "cpcc2_tiago", ["launch", "crocoddyl_controller.launch.py"],
#        prefix=['xterm -e gdb -ex run --args']
#    )


    print("flag 1")

    ld = LaunchDescription()
    
    ld.add_action(pveg_chained_controller_launch)

    ld.add_action(
        TimerAction(period=2.0, actions=[crocoddyl_controller_launch])
    )  # We wait for the pveg_chained_controller to fully load,then launch the crocoddyl one

    return ld



