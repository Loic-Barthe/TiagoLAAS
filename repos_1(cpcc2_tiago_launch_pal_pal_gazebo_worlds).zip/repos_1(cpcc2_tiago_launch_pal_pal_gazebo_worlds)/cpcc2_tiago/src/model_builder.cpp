#include <cpcc2_tiago/model_builder.hpp>
#include <iostream>




namespace cpcc2_tiago::model_builder {



pin::Model build_model(const std::string &urdf,
                       const std::vector<std::string> &joints) {
  // Load the urdf model
  pin::Model full_model;
  pin::urdf::buildModelFromXML(urdf, full_model);

  std::vector<std::string> actuatedJointNames = {"universe"};

  actuatedJointNames.insert(actuatedJointNames.end(), joints.begin(),
                            joints.end());

  std::vector<std::string> allJointNames = full_model.names;

  std::vector<std::string> jointsToLock;

  // Copy all elements from allJointNames that are not in actuatedJointNames
  // to jointsToLock
  
  std::cout << "flag 11" << std::endl;
  std::copy_if(allJointNames.begin(), allJointNames.end(),
               std::back_inserter(jointsToLock),
               [&actuatedJointNames](const std::string &s) {
                 return std::find(actuatedJointNames.begin(),
                                  actuatedJointNames.end(),
                                  s) == actuatedJointNames.end();
               });

  std::vector<pin::FrameIndex> jointsToLockIDs;

  for (std::string jn : jointsToLock)
    if (full_model.existJointName(jn))
      jointsToLockIDs.push_back(full_model.getJointId(jn));
  
  std::cout << "jointsToLockIDs:" << std::endl;
  for( const auto &aJointToLock : jointsToLockIDs )
  {
     std::cout << aJointToLock << std::endl;
  }
  Eigen::VectorXd q0 = Eigen::VectorXd::Zero(full_model.nq);
  
  std::cout << "flag 33" << std::endl;
  printf("full_model : %d\n", full_model);
    
  std::cout << "full_model = " << full_model << std::endl;

  for (pin::FrameIndex aJointToLock: jointsToLockIDs)
    std::cout << aJointToLock << " ";
  std::cout << std::endl;

  
  std::cout << "q0 = " << q0 << std::endl;
  
  std::cout << "flag 44" <<std::endl;
  pin::Model rModel=buildReducedModel(full_model, jointsToLockIDs, q0);
  std::cout << "flag 55" <<std::endl;
  return rModel;
}

void update_reduced_model(const Eigen::Ref<const Eigen::VectorXd> &x,
                          const pin::Model &model, pin::Data &data) {
  // x is the reduced posture, or contains the reduced posture in the first
  // elements
  pin::forwardKinematics(model, data, x.head(model.nq));
  pin::updateFramePlacements(model, data);
}

pin::SE3 get_end_effector_SE3(const pin::Data &data,
                              pin::FrameIndex end_effector_id) {
  return data.oMf[end_effector_id];
}

}  // namespace cpcc2_tiago::model_builder
