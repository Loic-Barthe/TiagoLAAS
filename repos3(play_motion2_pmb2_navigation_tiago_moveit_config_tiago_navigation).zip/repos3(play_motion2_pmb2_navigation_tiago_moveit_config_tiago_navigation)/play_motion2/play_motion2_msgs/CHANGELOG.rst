^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package play_motion2_msgs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.3.0 (2024-09-10)
------------------
* Create services to add and remove motions
* Add service to get the info of a motion
* Contributors: Noel Jimenez

1.2.0 (2024-08-09)
------------------

1.1.2 (2024-07-04)
------------------

1.1.1 (2024-04-26)
------------------

1.1.0 (2024-04-03)
------------------

1.0.1 (2024-03-07)
------------------

1.0.0 (2024-02-28)
------------------

0.0.15 (2024-01-15)
-------------------

0.0.14 (2024-01-08)
-------------------

0.0.13 (2023-12-14)
-------------------

0.0.12 (2023-11-14)
-------------------
* Add website tag
* Contributors: Noel Jimenez

0.0.11 (2023-11-13)
-------------------

0.0.10 (2023-10-02)
-------------------

0.0.9 (2023-07-05)
------------------

0.0.8 (2023-05-22)
------------------

0.0.7 (2023-04-17)
------------------
* add linters properly for interfaces
* Contributors: Noel Jimenez

0.0.6 (2023-03-20)
------------------

0.0.5 (2023-03-01)
------------------

0.0.4 (2023-02-23)
------------------

0.0.3 (2023-02-15)
------------------

0.0.2 (2023-02-08)
------------------
* Merge branch 'add_missing_dependency' into 'humble-devel'
  add missing dependency action_msgs
  See merge request app-tools/play_motion2!12
* add missing dependency action_msgs
* Contributors: Jordan Palacios, Noel Jimenez

0.0.1 (2023-02-08)
------------------
* Merge branch 'syntax_fixes' into 'humble-devel'
  fix eol and rm whitespaces
  See merge request app-tools/play_motion2!5
* fix eol and remove whitespace
* Merge branch 'jtc_motions' into 'humble-devel'
  New PlayMotion2 action: Manage requests and tests
  See merge request app-tools/play_motion2!3
* new srv IsMotionReady
* PlayMotion2 action
* Merge branch 'first_version' into 'humble-devel'
  First version of PlayMotion2 - parse motions
  See merge request app-tools/play_motion2!1
* ListMotions service
* new play_motion2_msgs package
* Contributors: Jordan Palacios, Noel Jimenez
