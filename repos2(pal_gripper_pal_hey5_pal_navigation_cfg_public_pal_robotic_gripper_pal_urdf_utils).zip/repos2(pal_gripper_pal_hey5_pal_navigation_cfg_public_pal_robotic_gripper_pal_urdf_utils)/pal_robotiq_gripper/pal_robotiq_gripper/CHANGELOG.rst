^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package pal_robotiq_gripper
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

2.2.0 (2024-08-07)
------------------

2.1.0 (2024-07-31)
------------------

2.0.3 (2024-05-06)
------------------

2.0.2 (2024-03-25)
------------------

2.0.1 (2024-03-06)
------------------

2.0.0 (2024-01-17)
------------------
* updating license to apache
* merging the 85 and 140 package into pal_robotiq_description
* adapting package.xml & Cmake to the new structure
* adding myself as maintainer
* basic ros to ros2 changes
* Cmake changes
* Contributors: Aina Irisarri

0.0.19 (2023-05-11)
-------------------

0.0.18 (2023-03-23)
-------------------

0.0.17 (2023-02-27)
-------------------

0.0.16 (2023-02-15)
-------------------

0.0.15 (2023-01-12)
-------------------

0.0.14 (2023-01-10)
-------------------

0.0.13 (2022-09-29)
-------------------

0.0.12 (2022-09-23)
-------------------

0.0.11 (2022-05-04)
-------------------

0.0.10 (2022-03-23)
-------------------
* Merge branch 'add_dependency' into 'master'
  Add pal_robotiq_controller_configuration dependency
  See merge request robots/pal_robotiq_gripper!7
* Add pal_robotiq_controller_configuration dependency
* Contributors: saikishor, thomaspeyrucain

0.0.9 (2022-03-21)
------------------

0.0.8 (2022-03-18)
------------------

0.0.7 (2021-11-18)
------------------

0.0.6 (2021-11-09)
------------------

0.0.5 (2021-09-07)
------------------

0.0.4 (2021-05-04)
------------------

0.0.3 (2021-04-21)
------------------

0.0.2 (2021-04-21)
------------------

0.0.1 (2021-04-21)
------------------
* Added the dependencies to the robotiq packages
* added pal_robotiq_85_gripper metapackage
* added the metapackage
* added the metapackage
* Contributors: Sai Kishor Kothakota
