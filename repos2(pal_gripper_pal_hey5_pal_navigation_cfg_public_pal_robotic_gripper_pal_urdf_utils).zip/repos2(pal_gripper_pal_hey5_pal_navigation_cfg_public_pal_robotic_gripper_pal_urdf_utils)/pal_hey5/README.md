pal_hey5
----

pal_hey5 related packages

Contains:

* pal_hey5_description: with its URDF and test files.
* pal_hey5_controller_configuration: with some example configuration.
