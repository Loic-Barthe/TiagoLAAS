^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package pal_hey5_controller_configuration
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

4.2.0 (2024-08-07)
------------------
* Use controller_type from the controllers config
* Contributors: Noel Jimenez

4.1.0 (2024-01-18)
------------------
* Merge branch 'tiago-dual-ros2' into 'humble-devel'
  Add parametric yaml file and end_effector side for tiago dual
  See merge request robots/pal_hey5!4
* Update variable name of gripper_prefix
* fix typo
* Change to ee_suffix
* Add parametric yaml file and gripper side for tiago dual
* Contributors: David ter Kuile, davidterkuile

4.0.1 (2023-12-18)
------------------

4.0.0 (2023-12-15)
------------------
* rename pal_hey_controllers.yaml into pal_hey_controller.yaml
* creating the pal_hey5_controller_configuration package
* Contributors: Aina Irisarri

* rename pal_hey_controllers.yaml into pal_hey_controller.yaml
* creating the pal_hey5_controller_configuration package
* Contributors: Aina Irisarri

3.0.4 (2023-11-14)
------------------

3.0.3 (2023-06-27)
------------------

3.0.2 (2022-11-29)
------------------

3.0.1 (2022-11-03)
------------------

3.0.0 (2022-10-26)
------------------

1.0.3 (2019-04-15)
------------------

1.0.2 (2018-04-13)
------------------

1.0.1 (2018-01-15)
------------------

1.0.0 (2016-09-01 08:53:16 +0200)
---------------------------------

0.1.3 (2016-04-25)
------------------

0.1.2 (2015-06-12 16:52)
------------------------

0.1.1 (2015-06-12 16:29)
------------------------

0.1.0 (2015-04-22)
------------------

0.0.6 (2015-01-15)
------------------

0.0.5 (2014-12-23)
------------------

0.0.4 (2014-12-12)
------------------

0.0.3 (2014-11-13 10:50)
------------------------

0.0.2 (2014-11-13 09:29)
------------------------

0.0.1 (2014-11-05)
------------------
