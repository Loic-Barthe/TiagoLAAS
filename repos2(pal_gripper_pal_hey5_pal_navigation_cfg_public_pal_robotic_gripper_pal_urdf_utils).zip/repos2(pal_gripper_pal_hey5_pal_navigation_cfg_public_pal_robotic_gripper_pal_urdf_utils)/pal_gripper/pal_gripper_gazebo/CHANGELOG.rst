^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package pal_gripper_gazebo
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.0.3 (2020-04-30)
------------------

1.0.2 (2019-06-11)
------------------

1.0.1 (2019-03-26)
------------------

1.0.0 (2018-07-30)
------------------

0.0.13 (2018-04-13)
-------------------

0.0.12 (2018-02-20)
-------------------
* install launch files
* Contributors: Jordi Pages

0.0.11 (2018-01-24)
-------------------

0.0.10 (2018-01-24)
-------------------
* move scripts and config files from tiago_robot
* Contributors: Jordi Pages

0.0.9 (2016-10-14)
------------------
* fix maintainer
* 0.0.8
* Update changelog
* 0.0.7
* Update changelogs
* 0.0.6
* Update cahngelog
* 0.0.5
* Update changelog
* 0.0.4
* Update changelgo
* 0.0.3
* Update changelogs
* 0.0.2
* Updated the changelog
* Contributors: Hilario Tome, Jordi Pages, Sam Pfeiffer, Victor Lopez

0.0.1 (2016-06-01)
------------------
* Initial version
* Contributors: Sam Pfeiffer
