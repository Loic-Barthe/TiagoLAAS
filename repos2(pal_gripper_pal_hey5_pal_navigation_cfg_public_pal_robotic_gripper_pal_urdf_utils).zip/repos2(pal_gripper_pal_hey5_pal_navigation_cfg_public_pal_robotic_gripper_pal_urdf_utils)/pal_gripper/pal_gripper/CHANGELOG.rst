^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package pal_gripper
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

3.3.0 (2024-08-07)
------------------

3.2.0 (2024-06-18)
------------------

3.1.0 (2024-01-18)
------------------
* Merge branch 'tiago-dual' into 'humble-devel'
  Adapted pal_gripper_controller_configuration to ros2
  See merge request robots/pal_gripper!32
* CMake version to 3.8
* Contributors: David ter Kuile, davidterkuile

3.0.7 (2023-12-12)
------------------

3.0.6 (2023-12-11)
------------------

3.0.5 (2023-11-14)
------------------
* Add website tag
* Contributors: Noel Jimenez

3.0.4 (2023-04-17)
------------------

3.0.3 (2023-03-01)
------------------

3.0.2 (2023-02-08)
------------------

3.0.1 (2022-12-15)
------------------

3.0.0 (2022-10-26)
------------------
* Merge branch 'update_copyright' into 'humble-devel'
  Update copyright and add LICENSE
  See merge request robots/pal_gripper!15
* update copyright and add license
* Merge branch 'update_maintainers' into 'humble-devel'
  update maintainers
  See merge request robots/pal_gripper!14
* update maintainers
* ros2 format. Disabled some packages
* Contributors: Jordan Palacios, Noel Jimenez

1.0.3 (2020-04-30)
------------------

1.0.2 (2019-06-11)
------------------

1.0.1 (2019-03-26)
------------------

1.0.0 (2018-07-30)
------------------

0.0.13 (2018-04-13)
-------------------

0.0.12 (2018-02-20)
-------------------

0.0.11 (2018-01-24)
-------------------

0.0.10 (2018-01-24)
-------------------
* move scripts and config files from tiago_robot
* Contributors: Jordi Pages

0.0.9 (2016-10-14)
------------------
* fix maintainer
* 0.0.8
* Update changelog
* 0.0.7
* Update changelogs
* 0.0.6
* Update cahngelog
* 0.0.5
* Update changelog
* 0.0.4
* Update changelgo
* 0.0.3
* Update changelogs
* 0.0.2
* Updated the changelog
* Contributors: Hilario Tome, Jordi Pages, Sam Pfeiffer, Victor Lopez

0.0.1 (2016-06-01)
------------------
* Initial version
* Contributors: Sam Pfeiffer
