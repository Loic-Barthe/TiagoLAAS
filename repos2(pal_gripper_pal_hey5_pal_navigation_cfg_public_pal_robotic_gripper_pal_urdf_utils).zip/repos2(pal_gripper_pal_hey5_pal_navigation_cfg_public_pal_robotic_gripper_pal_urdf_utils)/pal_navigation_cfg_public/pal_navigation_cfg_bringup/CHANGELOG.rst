^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package pal_navigation_cfg_bringup
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

3.0.6 (2023-11-14)
------------------

3.0.5 (2023-07-21)
------------------
* Fix license
* Remove pal flags dependency
* compatibility with monitor
* Contributors: Noel Jimenez, antoniobrandi

3.0.4 (2023-05-02)
------------------

3.0.3 (2023-04-25)
------------------
* Merge branch 'fix/missing_dependency' into 'humble-devel'
  Add missing dependency nav2_bringup
  See merge request navigation/pal_navigation_cfg_public!47
* add missing dependency nav2_bringup
* Contributors: Noel Jimenez, antoniobrandi

3.0.2 (2023-04-05)
------------------
* Merge branch 'license' into 'humble-devel'
  Add license
  See merge request navigation/pal_navigation_cfg_public!46
* Update license
* Contributors: Noel Jimenez, antoniobrandi

3.0.1 (2023-04-04)
------------------
* Merge branch 'fix/unify-nav' into 'humble-devel'
  unify nav launch files
  See merge request navigation/pal_navigation_cfg_public!45
* unify nav launch files
* added default parameters and launch files
* init ROS2 migration
* Contributors: antoniobrandi
