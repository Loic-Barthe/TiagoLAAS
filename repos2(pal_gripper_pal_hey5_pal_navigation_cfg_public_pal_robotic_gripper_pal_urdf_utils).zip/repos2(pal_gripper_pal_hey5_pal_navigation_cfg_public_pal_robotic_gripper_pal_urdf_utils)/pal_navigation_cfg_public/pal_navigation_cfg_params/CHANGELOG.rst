^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package pal_navigation_cfg_params
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

3.0.6 (2023-11-14)
------------------

3.0.5 (2023-07-21)
------------------
* Remove pal flags dependency
* compatibility with monitor
* Contributors: Noel Jimenez, antoniobrandi

3.0.4 (2023-05-02)
------------------
* Merge branch 'fix/add-odom-topic' into 'humble-devel'
  Add odom_topic to controller server node
  See merge request navigation/pal_navigation_cfg_public!48
* Add odom_topic to controller server node
* Contributors: antoniobrandi

3.0.3 (2023-04-25)
------------------

3.0.2 (2023-04-05)
------------------
* Merge branch 'license' into 'humble-devel'
  Add license
  See merge request navigation/pal_navigation_cfg_public!46
* Update license
* Contributors: Noel Jimenez, antoniobrandi

3.0.1 (2023-04-04)
------------------
* added default parameters and launch files
* init ROS2 migration
* Contributors: antoniobrandi
