^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package pal_urdf_utils
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

2.0.1 (2023-12-19)
------------------
* Add website tag
* Add xml version
* Contributors: Noel Jimenez

2.0.0 (2023-11-22)
------------------
* Merge branch 'port-to-ros2' into 'humble-devel'
  Port package.xml and CMakeLists.txt
  See merge request robots/pal_urdf_utils!2
* Change branch name in contributing
* add contributing.md
* Add licence
* Update extensions of files to .urdf.xacro
* Remove ament python dependency
* Port package.xml and CMakeLists.txt
* Contributors: David ter Kuile, davidterkuile

0.0.1 (2023-10-18)
------------------
* Merge branch 'feat/use_urdf_utils' into 'master'
  Remove unecessary files + update materials
  See merge request robots/pal_urdf_utils!1
* Add new color and adapt Orange
* Remove unecessary files + update materials
* wip testing
* fix plugin_imu
* wip testing
* add gazebo plugins
* project upload
* [empty] Initial commit
* Contributors: Jeremie Deray, Jordan Palacios, thomaspeyrucain
